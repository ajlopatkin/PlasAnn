"""Main entry point for the plasann package."""

from .annotate_plasmid import main

if __name__ == "__main__":
    main()